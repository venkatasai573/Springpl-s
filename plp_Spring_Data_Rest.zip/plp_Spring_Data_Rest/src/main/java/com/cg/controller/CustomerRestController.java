package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.service.WalletServiceImpl;

@RestController
public class CustomerRestController {

	@Autowired
	WalletServiceImpl walletServiceImpl;
	@Autowired
	Customer customer;

	/*
	 * POST http://localhost:8088/customer/create
	 */
	@PostMapping(value = "/create", produces = "application/json", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Customer createAccount(@RequestBody Customer customer) {
		return walletServiceImpl.createAccount(customer);
	}
	
	

	/*
	 * POST  http://localhost:8088/deposit
	 */
	@GetMapping(value = "/showbalance/{customerId}")
	public Double showBalance(@PathVariable Integer customerId) {
		return walletServiceImpl.showBalance(customerId);
	}
	
	/*
	 * POST  http://localhost:8088/deposit
	 */
	@PostMapping(value = "/deposit/{customerId}/{amount}")
	public void depositAmount(@PathVariable Integer customerId, @PathVariable Double amount) {
		walletServiceImpl.deposit(customerId, amount);
	}

	/*
	 * POST http://localhost:8088/withdraw
	 */
	@PostMapping(value = "/withdraw/{customerId}/{amount}")
	public void withdrawAmount(@PathVariable Integer customerId, @PathVariable Double amount)  {
		System.out.println(customerId+"--"+amount);
		walletServiceImpl.withdraw(customerId, amount);
	}

	/*
	 * POST http://localhost:8088/fundtransfer
	 */
	@PostMapping(value = "/fundtransfer/{sendercustomerId}/{receivercustomerId}/{amount}")
	public void fundTransfer(@PathVariable Integer sendercustomerId,@PathVariable Integer receivercustomerId, @PathVariable Double amount)  {
		walletServiceImpl.fundTransfer(sendercustomerId, receivercustomerId, amount);
	}

	/*
	 * Get http://localhost:8088/printtransaction
	 */
	@GetMapping(value = "/printtransaction/{customerId}")
	public List<Transaction> printTransaction(@PathVariable Integer customerId)  {
		return walletServiceImpl.printTransaction(customerId);
	}
	
	@RequestMapping(value = "/display")
	public String dummy() {
		return "Sheetal";
	}

}
