package com.cg.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
/***
 * 
 * @author shesahu
 *
 */
@Entity
@Table(name="Wallet_Customer_spring_jpa")
@Component
public class Customer implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "myseq")
	@SequenceGenerator(name = "myseq",sequenceName = "customersequencespringjpa",allocationSize = 1,initialValue =4000)
	@Column(length = 5)
	private int customerId;
	@Column(length = 20)
	private String customerName;
	@Column(length = 10)
	private String dateOfBirth;
	@Column(length = 10)
	private String phone;
	@Column(length = 20)
	private String email;
	@Column(length = 30)
	private String address;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "accountno")
	@Autowired
	private Account account;
	@OneToMany(mappedBy = "customer",cascade = CascadeType.ALL)
	@Autowired
	private List<Transaction> transactionList = new ArrayList<Transaction>();
		public Customer() {
		super();
	}
	public Customer(int customerId, String customerName, String dateOfBirth, String phone, String email, String address,
			Account account, List<Transaction> transactionList) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.account = account;
		this.transactionList = transactionList;
	}
	public Customer(String customerName, String dateOfBirth, String phone, String email, String address,
			Account account,List<Transaction> transactionList) {
		super();
		this.customerName = customerName;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.account = account;
		this.transactionList = transactionList;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public List<Transaction> getTransactionList() {
		return transactionList;
	}
	public void setTransactionList(List<Transaction> transactionList) {
		this.transactionList = transactionList;
	}
	@Override
	public String toString() {
		return "\ncustomerId=" + customerId + ",\ncustomerName=" + customerName + ",\ndateOfBirth=" + dateOfBirth
				+ ",\nphone=" + phone + ",\nemail=" + email + ",\naddress=" + address + ",\naccount=" + account
				+ ",\ntransactionList=" + transactionList;
	}
	
}
